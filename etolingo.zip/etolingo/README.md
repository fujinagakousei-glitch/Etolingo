# 🇫🇷 Etolingo

フランス語学習アプリ（Duolingo風）

## Vercelへのデプロイ手順

1. このフォルダをGitHubにアップロード
2. vercel.com でGitHubリポジトリを選択
3. そのままDeployボタンを押す

## ローカルで動かす場合

```bash
npm install
npm run dev
```
